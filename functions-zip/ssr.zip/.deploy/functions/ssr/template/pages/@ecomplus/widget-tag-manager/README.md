# Widget Tag Manager

[![CodeFactor](https://www.codefactor.io/repository/github/ecomclub/widget-tag-manager/badge)](https://www.codefactor.io/repository/github/ecomclub/widget-tag-manager)
[![npm version](https://img.shields.io/npm/v/@ecomplus/widget-tag-manager.svg)](https://www.npmjs.org/@ecomplus/widget-tag-manager)
[![license mit](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Storefront plugin to handle GTM with ecommerce data layer

[Changelog](https://github.com/ecomclub/widget-tag-manager/blob/master/CHANGELOG.md)
